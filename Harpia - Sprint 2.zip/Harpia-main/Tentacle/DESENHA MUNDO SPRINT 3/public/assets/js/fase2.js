/* =============================================
   DESENHA MUNDO — FASE 2
   Arquivo: fase2.js

   Cenário: pôr do sol.
   Mesmo personagem do JSON da Fase 1.
   Fase mais longa e desafiadora.
============================================= */

const canvas = document.getElementById('gameCanvas');
const ctx    = canvas.getContext('2d');

/* ── REDIMENSIONAR ── */
function redimensionar() {
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
}
redimensionar();
window.addEventListener('resize', redimensionar);

/* ── ESTADO DO JOGO ── */
const estado = {
  personagemImg: null,
  px: 0,
  py: 0,
  vx: 0,
  vy: 0,
  noChao:        true,
  viradoDireita: true,
  animFrame:     0,
  animTimer:     0,
  camera:        0,
  teclas:        {},
  correndo:      false,
  mundoLargura:  5200,
};

const SPRITE_W   = 72;
const SPRITE_H   = 72;
const VELOCIDADE = 3.4;
const GRAVIDADE  = 0.56;
const PULO       = -13;

/* ── CARREGAMENTO DO JSON ── */
const telaCarregando     = document.getElementById('telaCarregando');
const loadBarra          = document.getElementById('loadBarra');
const avisoSemPersonagem = document.getElementById('avisoSemPersonagem');

function simularBarra(cb) {
  let p = 0;
  const iv = setInterval(() => {
    p += Math.random() * 18 + 8;
    if (p >= 100) { p = 100; clearInterval(iv); setTimeout(cb, 300); }
    loadBarra.style.width = p + '%';
  }, 120);
}

function carregarPersonagem() {
  let dadosStr = localStorage.getItem('personagem_desenho');

  if (!dadosStr) {
    fetch('personagem_desenho.json')
      .then(r => { if (!r.ok) throw new Error(); return r.json(); })
      .then(dados => processarDados(dados))
      .catch(() => mostrarAviso());
    return;
  }

  try {
    processarDados(JSON.parse(dadosStr));
  } catch (e) {
    mostrarAviso();
  }
}

function processarDados(dados) {
  const oc   = document.createElement('canvas');
  oc.width   = dados.canvas.largura;
  oc.height  = dados.canvas.altura;
  const octx = oc.getContext('2d');
  octx.lineCap  = 'round';
  octx.lineJoin = 'round';

  dados.tracos.forEach(t => {
    if (!t.pontos || t.pontos.length < 2) return;
    octx.beginPath();
    octx.strokeStyle = t.cor;
    octx.lineWidth   = t.espessura;
    octx.moveTo(t.pontos[0].x, t.pontos[0].y);
    for (let i = 1; i < t.pontos.length; i++) octx.lineTo(t.pontos[i].x, t.pontos[i].y);
    octx.stroke();
  });

  createImageBitmap(oc).then(bmp => {
    estado.personagemImg = bmp;
    simularBarra(() => iniciarJogo());
  });
}

function mostrarAviso() {
  telaCarregando.style.display = 'none';
  avisoSemPersonagem.classList.add('visivel');
}

/* =============================================
   CENÁRIO — ELEMENTOS GERADOS UMA VEZ
============================================= */
const MUNDO_W = estado.mundoLargura;

/* Estrelas (aparecem no céu escuro do topo) */
const estrelas = Array.from({ length: 80 }, () => ({
  x:    Math.random() * MUNDO_W,
  y:    10 + Math.random() * (window.innerHeight * 0.38),
  r:    0.6 + Math.random() * 1.8,
  fase: Math.random() * Math.PI * 2,
}));

/* Partículas de brasa flutuando */
const brasas = Array.from({ length: 35 }, () => ({
  x:     Math.random() * MUNDO_W,
  y:     50 + Math.random() * 300,
  r:     1.5 + Math.random() * 2.5,
  vel:   0.3 + Math.random() * 0.5,
  fase:  Math.random() * Math.PI * 2,
  alpha: 0.4 + Math.random() * 0.5,
}));

/* Nuvens tingidas de laranja/rosa */
const nuvens = Array.from({ length: 16 }, () => ({
  x:     Math.random() * MUNDO_W,
  y:     40 + Math.random() * 120,
  r:     30 + Math.random() * 50,
  alpha: 0.35 + Math.random() * 0.35,
  cor:   ['#FF6B35', '#FF9A5C', '#C84B6E', '#FF7B8A', '#FFB347'][Math.floor(Math.random() * 5)],
}));

/* Silhuetas de árvores (pinheiros altos) */
const arvores = Array.from({ length: 26 }, (_, i) => ({
  x: 100 + i * 195 + Math.random() * 70,
  h: 80  + Math.random() * 80,
  r: 20  + Math.random() * 20,
}));

/* Arbustos rasteiros na frente */
const arbustos = Array.from({ length: 40 }, (_, i) => ({
  x: 60 + i * 120 + Math.random() * 50,
  r: 14 + Math.random() * 12,
}));

/* ── CHÃO ── */
const CHAO_Y = () => canvas.height - 110;

/* ── PLATAFORMAS (baixinhas e bem espaçadas — fácil para crianças) ── */
const plataformas = [
  { x: 380,  y: () => CHAO_Y() - 70,  w: 160 },
  { x: 680,  y: () => CHAO_Y() - 80,  w: 160 },
  { x: 990,  y: () => CHAO_Y() - 70,  w: 170 },
  { x: 1290, y: () => CHAO_Y() - 80,  w: 160 },
  { x: 1590, y: () => CHAO_Y() - 70,  w: 170 },
  { x: 1900, y: () => CHAO_Y() - 80,  w: 160 },
  { x: 2200, y: () => CHAO_Y() - 70,  w: 170 },
  { x: 2510, y: () => CHAO_Y() - 80,  w: 160 },
  { x: 2810, y: () => CHAO_Y() - 70,  w: 170 },
  { x: 3120, y: () => CHAO_Y() - 80,  w: 160 },
  { x: 3420, y: () => CHAO_Y() - 70,  w: 170 },
  { x: 3730, y: () => CHAO_Y() - 80,  w: 160 },
  { x: 4030, y: () => CHAO_Y() - 70,  w: 170 },
  { x: 4330, y: () => CHAO_Y() - 80,  w: 160 },
];

/* ── MOEDAS ── */
const moedas = [];
plataformas.forEach(p => {
  /* Três moedas em cima de cada plataforma */
  for (let i = 0; i < 3; i++) {
    moedas.push({ x: p.x + p.w * (0.25 + i * 0.25), y: () => p.y() - 28, coletada: false });
  }
});
/* Muitas moedas no chão para coletar facilmente */
for (let i = 0; i < 26; i++) {
  moedas.push({ x: 200 + i * 175, y: () => CHAO_Y() - 50, coletada: false });
}
let pontos = 0;

/* Meta */
const META_X = 4950;

/* ── INICIAR JOGO ── */
function iniciarJogo() {
  estado.px = 80;
  estado.py = CHAO_Y() - SPRITE_H;

  telaCarregando.classList.add('saindo');
  setTimeout(() => { telaCarregando.style.display = 'none'; }, 700);

  setTimeout(() => {
    document.getElementById('dicaBalao').classList.add('oculto');
  }, 4000);

  loop();
}

/* ── INPUT ── */
document.addEventListener('keydown', e => { estado.teclas[e.code] = true;  });
document.addEventListener('keyup',   e => { estado.teclas[e.code] = false; });

const btnE = document.getElementById('btnEsquerda');
const btnD = document.getElementById('btnDireita');

function pressionarBtn(btn, code, ativo) {
  btn.classList.toggle('pressionado', ativo);
  estado.teclas[code] = ativo;
}
btnE.addEventListener('pointerdown',  () => pressionarBtn(btnE, 'ArrowLeft',  true));
btnE.addEventListener('pointerup',    () => pressionarBtn(btnE, 'ArrowLeft',  false));
btnE.addEventListener('pointerleave', () => pressionarBtn(btnE, 'ArrowLeft',  false));
btnD.addEventListener('pointerdown',  () => pressionarBtn(btnD, 'ArrowRight', true));
btnD.addEventListener('pointerup',    () => pressionarBtn(btnD, 'ArrowRight', false));
btnD.addEventListener('pointerleave', () => pressionarBtn(btnD, 'ArrowRight', false));

/* ── FÍSICA ── */
function atualizarFisica() {
  const esq  = estado.teclas['ArrowLeft']  || estado.teclas['KeyA'];
  const dir  = estado.teclas['ArrowRight'] || estado.teclas['KeyD'];
  const pulo = estado.teclas['ArrowUp']    || estado.teclas['KeyW'] || estado.teclas['Space'];

  if (dir)      { estado.vx = VELOCIDADE;  estado.viradoDireita = true;  estado.correndo = true;  }
  else if (esq) { estado.vx = -VELOCIDADE; estado.viradoDireita = false; estado.correndo = true;  }
  else          { estado.vx *= 0.82; estado.correndo = false; }

  if (pulo && estado.noChao) { estado.vy = PULO; estado.noChao = false; }

  estado.vy += GRAVIDADE;
  estado.px += estado.vx;
  estado.py += estado.vy;

  if (estado.px < 0)                                     { estado.px = 0; estado.vx = 0; }
  if (estado.px > estado.mundoLargura - SPRITE_W)        { estado.px = estado.mundoLargura - SPRITE_W; estado.vx = 0; }

  const chaoY = CHAO_Y();
  if (estado.py >= chaoY - SPRITE_H) {
    estado.py = chaoY - SPRITE_H;
    estado.vy = 0;
    estado.noChao = true;
  }

  plataformas.forEach(p => {
    const py = p.y();
    if (
      estado.px + SPRITE_W > p.x &&
      estado.px < p.x + p.w  &&
      estado.py + SPRITE_H >= py &&
      estado.py + SPRITE_H <= py + 20 &&
      estado.vy >= 0
    ) {
      estado.py = py - SPRITE_H;
      estado.vy = 0;
      estado.noChao = true;
    }
  });

  moedas.forEach(m => {
    if (m.coletada) return;
    const my = m.y();
    if (
      Math.abs(estado.px + SPRITE_W / 2 - m.x) < 30 &&
      Math.abs(estado.py + SPRITE_H / 2 - my)  < 30
    ) { m.coletada = true; pontos += 10; }
  });

  const alvo = estado.px - canvas.width / 3;
  estado.camera += (alvo - estado.camera) * 0.1;
  if (estado.camera < 0) estado.camera = 0;
  if (estado.camera > estado.mundoLargura - canvas.width)
    estado.camera = estado.mundoLargura - canvas.width;

  if (estado.correndo && estado.noChao) {
    estado.animTimer++;
    if (estado.animTimer > 8) { estado.animFrame = (estado.animFrame + 1) % 4; estado.animTimer = 0; }
  } else if (!estado.correndo) { estado.animFrame = 0; }

  verificarMeta();
}

/* =============================================
   RENDERIZAÇÃO — CÉU PÔR DO SOL
============================================= */
let tempo = 0;

/* Posição do sol: começa alto (laranja) e "desce" conforme o nível avança */
function progresso() {
  return Math.min(1, estado.camera / (estado.mundoLargura - canvas.width || 1));
}

function desenharCeu() {
  const w = canvas.width, h = canvas.height;
  const p = progresso(); /* 0 = início, 1 = final da fase */

  /* Interpola o gradiente: dia quente → entardecer → crepúsculo */
  const grad = ctx.createLinearGradient(0, 0, 0, h);

  /* Topo: azul profundo → roxo escuro conforme avança */
  const r0 = lerp(28,  12,  p), g0 = lerp(16,  8,  p), b0 = lerp(64, 32, p);
  /* Meio: laranja intenso → vinho */
  const r1 = lerp(255, 180, p), g1 = lerp(110, 40, p), b1 = lerp(50,  60, p);
  /* Horizonte: dourado → laranja escuro */
  const r2 = lerp(255, 220, p), g2 = lerp(180,  80, p), b2 = lerp(60, 30, p);

  grad.addColorStop(0,    `rgb(${r0|0},${g0|0},${b0|0})`);
  grad.addColorStop(0.45, `rgb(${r1|0},${g1|0},${b1|0})`);
  grad.addColorStop(1,    `rgb(${r2|0},${g2|0},${b2|0})`);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}

function lerp(a, b, t) { return a + (b - a) * t; }

function desenharSol() {
  const p      = progresso();
  /* Sol desce de ~20 % da altura até ~65 % (quase no horizonte) */
  const solY   = canvas.height * lerp(0.18, 0.62, p);
  /* Posição horizontal: ligeiramente à direita do meio, paralaxe lenta */
  const solX   = canvas.width  * 0.62 - estado.camera * 0.04;
  const raio   = lerp(56, 70, p);

  /* Halo externo */
  const halo = ctx.createRadialGradient(solX, solY, raio * 0.4, solX, solY, raio * 3.2);
  halo.addColorStop(0,   `rgba(255,180,60,${lerp(0.30, 0.18, p)})`);
  halo.addColorStop(0.5, `rgba(255,100,30,${lerp(0.12, 0.07, p)})`);
  halo.addColorStop(1,   'rgba(255,60,10,0)');
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(solX, solY, raio * 3.2, 0, Math.PI * 2);
  ctx.fill();

  /* Disco do sol */
  const discGrad = ctx.createRadialGradient(solX - raio * 0.2, solY - raio * 0.2, 2, solX, solY, raio);
  discGrad.addColorStop(0, '#FFF4AA');
  discGrad.addColorStop(0.4, '#FFCC44');
  discGrad.addColorStop(1, `rgb(${lerp(255,200,p)|0},${lerp(110,50,p)|0},20)`);
  ctx.fillStyle = discGrad;
  ctx.beginPath();
  ctx.arc(solX, solY, raio, 0, Math.PI * 2);
  ctx.fill();

  /* Reflexo no chão (coluna de luz) */
  const chaoY = CHAO_Y();
  const reflexo = ctx.createLinearGradient(0, solY + raio, 0, chaoY);
  reflexo.addColorStop(0,   `rgba(255,180,60,${lerp(0.22, 0.12, p)})`);
  reflexo.addColorStop(1,   'rgba(255,100,30,0)');
  ctx.fillStyle = reflexo;
  const lw = raio * 2.5;
  ctx.fillRect(solX - lw / 2, solY + raio, lw, chaoY - solY - raio);
}

function desenharEstrelas() {
  tempo += 0.02;
  const p = progresso();
  /* Estrelas ficam mais visíveis conforme o céu escurece */
  const visibilidade = Math.max(0, (p - 0.2) * 2);
  if (visibilidade <= 0) return;

  estrelas.forEach(e => {
    const sx = e.x - estado.camera * 0.03;
    const sy = e.y;
    if (sx < -4 || sx > canvas.width + 4) return;
    /* Só aparecem na metade superior */
    const altura = sy / canvas.height;
    if (altura > 0.42) return;
    const brilho = visibilidade * (0.3 + 0.7 * Math.abs(Math.sin(tempo + e.fase)));
    ctx.beginPath();
    ctx.arc(sx, sy, e.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255,240,200,${brilho})`;
    ctx.fill();
  });
}

function desenharNuvens() {
  nuvens.forEach(n => {
    const nx = n.x - estado.camera * 0.22;
    if (nx < -150 || nx > canvas.width + 150) return;
    ctx.save();
    ctx.globalAlpha = n.alpha;
    ctx.fillStyle   = n.cor;
    ctx.beginPath();
    ctx.arc(nx,               n.y,             n.r,        0, Math.PI * 2);
    ctx.arc(nx + n.r * 0.85,  n.y - n.r * 0.3, n.r * 0.75, 0, Math.PI * 2);
    ctx.arc(nx - n.r * 0.75,  n.y - n.r * 0.2, n.r * 0.65, 0, Math.PI * 2);
    ctx.arc(nx + n.r * 1.5,   n.y + n.r * 0.1, n.r * 0.55, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  });
}

function desenharBrasas() {
  brasas.forEach(b => {
    const bx = ((b.x - estado.camera * 0.5) % (MUNDO_W + 200) + MUNDO_W + 200) % (MUNDO_W + 200) - 100;
    if (bx < -10 || bx > canvas.width + 10) return;
    const by = b.y - (tempo * b.vel * 30 % canvas.height);
    const drift = Math.sin(tempo * 0.8 + b.fase) * 12;
    ctx.beginPath();
    ctx.arc(bx + drift, by, b.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255,${Math.floor(lerp(120, 200, Math.random()))},40,${b.alpha * 0.7})`;
    ctx.fill();
  });
}

/* Montanhas em silhueta — camadas de paralaxe */
function desenharMontanhas() {
  const off1 = estado.camera * 0.30;
  const off2 = estado.camera * 0.50;
  const h    = canvas.height;

  /* Camada traseira — montanhas suaves, roxo escuro */
  ctx.beginPath();
  ctx.moveTo(0, h);
  for (let x = 0; x <= canvas.width + 60; x += 24) {
    const wx = x + off1;
    const y  = h - 160 + Math.sin(wx * 0.002) * 70 + Math.sin(wx * 0.005 + 1) * 40;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(canvas.width, h);
  ctx.closePath();
  ctx.fillStyle = 'rgba(40,16,70,0.85)';
  ctx.fill();

  /* Camada intermediária — mais nítida, vinho escuro */
  ctx.beginPath();
  ctx.moveTo(0, h);
  for (let x = 0; x <= canvas.width + 60; x += 18) {
    const wx = x + off2;
    const y  = h - 100 + Math.sin(wx * 0.003 + 2) * 48 + Math.sin(wx * 0.007) * 24;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(canvas.width, h);
  ctx.closePath();
  ctx.fillStyle = 'rgba(60,16,40,0.90)';
  ctx.fill();
}

/* Árvores em silhueta — pinheiros escuros */
function desenharArvores() {
  arvores.forEach(a => {
    const ax   = a.x - estado.camera;
    const base = CHAO_Y();
    if (ax < -60 || ax > canvas.width + 60) return;

    ctx.fillStyle = 'rgba(18,8,32,0.95)';

    /* Tronco */
    ctx.fillRect(ax - 4, base - a.h * 0.35, 8, a.h * 0.35);

    /* Copa triangular em camadas */
    for (let i = 0; i < 3; i++) {
      const ty = base - a.h * 0.28 - i * (a.h * 0.28);
      const tw = a.r * (1.8 - i * 0.4);
      ctx.beginPath();
      ctx.moveTo(ax,      ty - a.h * 0.32);
      ctx.lineTo(ax - tw, ty);
      ctx.lineTo(ax + tw, ty);
      ctx.closePath();
      ctx.fill();
    }
  });
}

/* Arbustos rasteiros na frente */
function desenharArbustos() {
  arbustos.forEach(a => {
    const ax   = a.x - estado.camera;
    const base = CHAO_Y();
    if (ax < -40 || ax > canvas.width + 40) return;
    ctx.fillStyle = 'rgba(22,8,40,0.92)';
    ctx.beginPath();
    ctx.arc(ax,          base - a.r * 0.6,  a.r,       0, Math.PI * 2);
    ctx.arc(ax - a.r,    base - a.r * 0.3,  a.r * 0.7, 0, Math.PI * 2);
    ctx.arc(ax + a.r,    base - a.r * 0.3,  a.r * 0.7, 0, Math.PI * 2);
    ctx.fill();
  });
}

function desenharChao() {
  const chaoY = CHAO_Y();
  const p     = progresso();

  /* Solo quente: da grama seca ao terra escura */
  const grad = ctx.createLinearGradient(0, chaoY, 0, canvas.height);
  grad.addColorStop(0,    `rgb(${lerp(110, 70, p)|0},${lerp(60, 30, p)|0},${lerp(20, 10, p)|0})`);
  grad.addColorStop(0.18, `rgb(${lerp(90, 55, p)|0},${lerp(48, 24, p)|0},${lerp(16, 8, p)|0})`);
  grad.addColorStop(1,    `rgb(${lerp(60, 30, p)|0},${lerp(28, 12, p)|0},${lerp(8, 4, p)|0})`);
  ctx.fillStyle = grad;
  ctx.fillRect(0, chaoY, canvas.width, canvas.height - chaoY);

  /* Faixa de grama seca no topo */
  ctx.fillStyle = `rgba(${lerp(130, 80, p)|0},${lerp(70, 30, p)|0},10,1)`;
  ctx.fillRect(0, chaoY, canvas.width, 5);

  /* Sombra suave */
  ctx.fillStyle = 'rgba(0,0,0,0.12)';
  ctx.fillRect(0, chaoY + 5, canvas.width, 8);
}

function desenharPlataformas() {
  plataformas.forEach(p => {
    const px = p.x - estado.camera;
    const py = p.y();
    if (px > canvas.width + 20 || px + p.w < -20) return;

    /* Sombra */
    ctx.fillStyle = 'rgba(0,0,0,0.22)';
    ctx.beginPath();
    ctx.roundRect(px + 4, py + 6, p.w, 22, 8);
    ctx.fill();

    /* Base — pedra escura avermelhada */
    const g = ctx.createLinearGradient(0, py, 0, py + 22);
    g.addColorStop(0, '#7B3020');
    g.addColorStop(1, '#4A1810');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.roundRect(px, py, p.w, 22, 8);
    ctx.fill();

    /* Topo — pedra com reflexo dourado */
    const topo = ctx.createLinearGradient(px, py, px + p.w, py);
    topo.addColorStop(0,   '#C04830');
    topo.addColorStop(0.5, '#E07040');
    topo.addColorStop(1,   '#C04830');
    ctx.fillStyle = topo;
    ctx.beginPath();
    ctx.roundRect(px, py, p.w, 9, [8, 8, 0, 0]);
    ctx.fill();

    /* Brilho do pôr do sol na borda superior */
    ctx.fillStyle = 'rgba(255,180,60,0.18)';
    ctx.beginPath();
    ctx.roundRect(px + 2, py + 1, p.w - 4, 4, 4);
    ctx.fill();
  });
}

function desenharMoedas() {
  moedas.forEach(m => {
    if (m.coletada) return;
    const mx = m.x - estado.camera;
    if (mx < -20 || mx > canvas.width + 20) return;
    const my = m.y() + Math.sin(tempo * 3 + m.x * 0.01) * 4;

    /* Brilho externo pulsante */
    const glow = ctx.createRadialGradient(mx, my, 2, mx, my, 18);
    glow.addColorStop(0,   'rgba(255,220,80,0.35)');
    glow.addColorStop(1,   'rgba(255,140,20,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(mx, my, 18, 0, Math.PI * 2);
    ctx.fill();

    /* Disco */
    ctx.save();
    ctx.beginPath();
    ctx.arc(mx, my, 10, 0, Math.PI * 2);
    ctx.fillStyle   = '#FFD166';
    ctx.fill();
    ctx.strokeStyle = '#FF8C00';
    ctx.lineWidth   = 2;
    ctx.stroke();
    ctx.fillStyle     = '#FF8C00';
    ctx.font          = "bold 10px 'Nunito', sans-serif";
    ctx.textAlign     = 'center';
    ctx.textBaseline  = 'middle';
    ctx.fillText('★', mx, my);
    ctx.restore();
  });
}

function desenharMeta() {
  const mx   = META_X - estado.camera;
  const base = CHAO_Y();
  if (mx < -80 || mx > canvas.width + 80) return;

  /* Halo de chegada */
  const halo = ctx.createRadialGradient(mx, base - 50, 5, mx, base - 50, 80);
  halo.addColorStop(0,   'rgba(255,220,80,0.25)');
  halo.addColorStop(1,   'rgba(255,120,30,0)');
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(mx, base - 50, 80, 0, Math.PI * 2);
  ctx.fill();

  /* Mastro */
  ctx.strokeStyle = '#7B3020';
  ctx.lineWidth   = 4;
  ctx.beginPath();
  ctx.moveTo(mx, base);
  ctx.lineTo(mx, base - 100);
  ctx.stroke();

  /* Bandeira com tom de pôr do sol */
  const flagGrad = ctx.createLinearGradient(mx, base - 100, mx + 50, base - 65);
  flagGrad.addColorStop(0, '#FF6B35');
  flagGrad.addColorStop(1, '#FFD166');
  ctx.fillStyle = flagGrad;
  ctx.beginPath();
  ctx.moveTo(mx,      base - 100);
  ctx.lineTo(mx + 50, base - 80);
  ctx.lineTo(mx,      base - 60);
  ctx.closePath();
  ctx.fill();

  ctx.save();
  ctx.font          = "bold 14px 'Nunito', sans-serif";
  ctx.fillStyle     = '#fff';
  ctx.textAlign     = 'center';
  ctx.textBaseline  = 'middle';
  ctx.fillText('🏁', mx + 18, base - 80);
  ctx.restore();
}

function desenharPersonagem() {
  const px = Math.round(estado.px - estado.camera);
  const py = Math.round(estado.py);

  ctx.save();

  /* Sombra quente no chão */
  ctx.beginPath();
  ctx.ellipse(px + SPRITE_W / 2, CHAO_Y() + 4, SPRITE_W / 2 * 0.7, 6, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(80,20,0,0.30)';
  ctx.fill();

  if (!estado.viradoDireita) {
    ctx.translate(px + SPRITE_W, 0);
    ctx.scale(-1, 1);
    ctx.translate(-px, 0);
  }

  let balanco = 0;
  if (estado.correndo && estado.noChao)
    balanco = Math.sin(estado.animFrame * Math.PI / 2) * 2;

  let scaleY = 1;
  if (!estado.noChao) scaleY = estado.vy < 0 ? 1.15 : 0.9;

  ctx.translate(px + SPRITE_W / 2, py + SPRITE_H / 2);
  ctx.rotate(balanco * 0.04);
  ctx.scale(1, scaleY);
  ctx.translate(-(px + SPRITE_W / 2), -(py + SPRITE_H / 2));

  if (estado.personagemImg) {
    /* Contorno brilhante dourado (rim light do pôr do sol) */
    ctx.shadowColor  = 'rgba(255,180,60,0.80)';
    ctx.shadowBlur   = 10;
    ctx.drawImage(estado.personagemImg, px, py, SPRITE_W, SPRITE_H);
    ctx.shadowBlur   = 0;
    ctx.drawImage(estado.personagemImg, px, py, SPRITE_W, SPRITE_H);
  } else {
    ctx.beginPath();
    ctx.arc(px + SPRITE_W / 2, py + SPRITE_H / 2, SPRITE_W / 2, 0, Math.PI * 2);
    ctx.fillStyle = '#FF8C6B';
    ctx.fill();
  }

  ctx.restore();
}

function desenharPontuacao() {
  ctx.save();
  ctx.font          = "bold 18px 'Nunito', sans-serif";
  ctx.fillStyle     = '#FFD166';
  ctx.textAlign     = 'right';
  ctx.textBaseline  = 'top';
  ctx.shadowColor   = 'rgba(0,0,0,0.5)';
  ctx.shadowBlur    = 4;
  ctx.fillText('⭐ ' + pontos, canvas.width - 14, 54);
  ctx.restore();
}

/* ── LOOP ── */
let rodando = true;

function loop() {
  if (!rodando) return;
  atualizarFisica();

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  desenharCeu();
  desenharSol();
  desenharEstrelas();
  desenharNuvens();
  desenharBrasas();
  desenharMontanhas();
  desenharArvores();
  desenharArbustos();
  desenharChao();
  desenharPlataformas();
  desenharMoedas();
  desenharMeta();
  desenharPersonagem();
  desenharPontuacao();

  requestAnimationFrame(loop);
}

/* ── VITÓRIA ── */
let jogo_concluido = false;

function verificarMeta() {
  if (jogo_concluido) return;
  const centroX = estado.px + SPRITE_W / 2;
  if (centroX >= META_X - 20 && centroX <= META_X + 70) {
    jogo_concluido = true;
    rodando        = false;
    mostrarVitoria();
  }
}

function mostrarVitoria() {
  const telaVitoria     = document.getElementById('telaVitoria');
  const vitoriaPontos   = document.getElementById('vitoriaPontos');
  const vitoriaMensagem = document.getElementById('vitoriaMensagem');

  const total    = moedas.length;
  const coletadas = moedas.filter(m => m.coletada).length;
  const pct      = coletadas / total;
  const numEstrelas = pct >= 1 ? 3 : pct >= 0.5 ? 2 : 1;

  const mensagens = [
    'Você atravessou o pôr do sol! Pratique mais! 💪',
    'Muito bem! Ainda há moedas brilhando lá fora! 🌅',
    'INCRÍVEL! Você coletou tudo sob o pôr do sol! 🌟',
  ];

  vitoriaPontos.textContent   = '⭐ ' + pontos + ' pontos';
  vitoriaMensagem.textContent = mensagens[numEstrelas - 1];
  telaVitoria.classList.add('visivel');

  for (let i = 1; i <= 3; i++) {
    const el = document.getElementById('estrelaV' + i);
    if (i <= numEstrelas) {
      setTimeout(() => el.classList.add('acesa'), i * 350);
    } else {
      el.style.filter  = 'grayscale(1) opacity(0.25)';
      el.style.opacity = '0.3';
      setTimeout(() => { el.style.opacity = '0.3'; el.style.transform = 'scale(1)'; }, i * 350);
    }
  }

  setTimeout(() => lancarConfete(), 400);
}

function lancarConfete() {
  const cores = ['#FF6B35', '#FFD166', '#FF8C6B', '#C84B6E', '#FFB347', '#FF4500'];
  for (let i = 0; i < 60; i++) {
    const el = document.createElement('div');
    el.className               = 'confete-item';
    el.style.left              = Math.random() * 100 + 'vw';
    el.style.background        = cores[Math.floor(Math.random() * cores.length)];
    el.style.animationDuration = (1.8 + Math.random() * 2) + 's';
    el.style.animationDelay    = (Math.random() * 1.2) + 's';
    el.style.width             = (6 + Math.random() * 8)   + 'px';
    el.style.height            = (10 + Math.random() * 10) + 'px';
    el.style.borderRadius      = Math.random() > 0.5 ? '50%' : '2px';
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 5000);
  }
}

/* ── INICIAR ── */
carregarPersonagem();

const express = require('express');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/',      (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/fase1', (req, res) => res.sendFile(path.join(__dirname, 'public', 'fase1.html')));
app.get('/bonus', (req, res) => res.sendFile(path.join(__dirname, 'public', 'fase-bonus.html')));

/* ══════════════════════════════════════════════
   GERADOR DA FASE BÔNUS
══════════════════════════════════════════════ */
function gerarFaseBonus() {
  const TEMAS = [
    { nome: 'Noite Estrelada',    emoji: '🌙', ceuTopo: '#0a0520', ceuBase: '#1e1060', chaoTopo: '#2a4a30', chaoBase: '#1a3020', platTopo: '#7B5EA7', platBase1: '#4a2080', platBase2: '#2d1050' },
    { nome: 'Pôr do Sol',         emoji: '🌅', ceuTopo: '#c0392b', ceuBase: '#f39c12', chaoTopo: '#DEB887', chaoBase: '#8B6914', platTopo: '#E8A050', platBase1: '#8B4513', platBase2: '#5C2D0A' },
    { nome: 'Tundra Gelada',      emoji: '❄️',  ceuTopo: '#5DADE2', ceuBase: '#D6EAF8', chaoTopo: '#EBF5FB', chaoBase: '#85C1E9', platTopo: '#AED6F1', platBase1: '#2980B9', platBase2: '#1A5276' },
    { nome: 'Floresta Encantada', emoji: '🌿', ceuTopo: '#1B4F1B', ceuBase: '#27AE60', chaoTopo: '#58D68D', chaoBase: '#1E8449', platTopo: '#82E0AA', platBase1: '#1E8449', platBase2: '#145A32' },
    { nome: 'Vulcão Furioso',     emoji: '🌋', ceuTopo: '#1a0000', ceuBase: '#7B241C', chaoTopo: '#6B2800', chaoBase: '#3A1500', platTopo: '#FF6B35', platBase1: '#922B21', platBase2: '#5B160F' },
  ];

  const DIFICULDADES = [
    { nome: 'Fácil',   emoji: '😊', cor: '#5BB8A0', minW: 160, maxW: 230, minH: 55,  maxH: 110, minGap: 160, maxGap: 260, numPlat: 8,  gravidade: 0.45, velocidade: 3.0, pulo: -12 },
    { nome: 'Médio',   emoji: '😤', cor: '#F9A825', minW: 110, maxW: 180, minH: 80,  maxH: 160, minGap: 220, maxGap: 330, numPlat: 10, gravidade: 0.55, velocidade: 3.5, pulo: -13 },
    { nome: 'Difícil', emoji: '😈', cor: '#E05050', minW: 75,  maxW: 130, minH: 100, maxH: 200, minGap: 280, maxGap: 410, numPlat: 12, gravidade: 0.65, velocidade: 4.0, pulo: -14 },
  ];

  const seed = Date.now();
  let s = (seed % 2147483646) + 1;
  const rand    = () => { s = s * 16807 % 2147483647; return (s - 1) / 2147483646; };
  const randInt = (a, b) => Math.floor(rand() * (b - a + 1)) + a;

  const tema = TEMAS[randInt(0, TEMAS.length - 1)];
  const dif  = DIFICULDADES[randInt(0, DIFICULDADES.length - 1)];

  const plataformas = [];
  let curX = 350;
  for (let i = 0; i < dif.numPlat; i++) {
    const w = randInt(dif.minW, dif.maxW);
    const h = randInt(dif.minH, dif.maxH);
    plataformas.push({ x: curX, alturaOffset: h, w });
    curX += w + randInt(dif.minGap, dif.maxGap);
  }

  const metaX        = curX + 80;
  const mundoLargura = metaX + 500;

  const moedas = [];
  plataformas.forEach((p, i) => {
    const num = randInt(1, 3);
    for (let c = 0; c < num; c++) {
      moedas.push({ x: p.x + (p.w / (num + 1)) * (c + 1), tipo: 'plataforma', platIndex: i });
    }
  });
  for (let i = 0; i < 16; i++) {
    moedas.push({ x: 160 + i * 190, tipo: 'chao', alturaOffset: 50 });
  }

  return { seed, tema, dificuldade: { nome: dif.nome, emoji: dif.emoji, cor: dif.cor },
    mundoLargura, metaX, gravidade: dif.gravidade, velocidade: dif.velocidade,
    pulo: dif.pulo, plataformas, moedas };
}

app.get('/api/fase-bonus', (req, res) => res.json(gerarFaseBonus()));

app.listen(PORT, () => console.log(`🎮 Desenha Mundo rodando em http://localhost:${PORT}`));
